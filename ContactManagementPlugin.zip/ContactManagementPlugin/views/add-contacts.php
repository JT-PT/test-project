<?php
global $wpdb;
$all_contacts = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT * from contact", ""
    ), ARRAY_A
);

$action = isset($_GET['action']) ? trim($_GET['action']) : "";
$id = isset($_GET['id']) ? intval($_GET['id']) : "";
if (!empty($action) && $action == "delete") {

    $row_exists = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * from contact WHERE id = %d", $id
        )
    );
    if (count($row_exists) > 0) {
        $wpdb->delete("contact", array(
            "id" => $id
        ));
    }
    ?>
    <script>
        location.href = "<?php echo site_url() ?>/wp-admin/admin.php?page=PersonManagementPlugin-plugin";
    </script>
    <?php
}

if (count($all_contacts) > 0) {
    ?>
    <table cellpadding="10" border="1" width="100px">
        <tr>
            <th>Id</th>
            <th>CountryCode</th>
            <th>Number</th>
            <th>Action</th>
        </tr>
        <?php
        $count = 1;
        foreach ($all_contacts as $index => $contact) {
            ?>
            <tr>
                <td><?php echo $count++; ?></td>
                <td><?php echo $contact['countrycode'] ?></td>
                <td><?php echo $contact['number'] ?></td>
                <td>
                    <a href="admin.php?page=ContactManagementPlugin-add&action=edit&id=<?php echo $contact['id']; ?>">Edit</a>
                    <a href="admin.php?page=PersonManagementPlugin-plugin&id=<?php echo $contact['id']; ?>&action=delete" onclick="return confirm('Are you sure you want to delete this contact?')">Delete</a>
                </td>
            </tr>
            <?php
        }
        ?>
    </table>

    <?php
}
?>

<?php
global $wpdb;
$msg = '';

$action = isset($_GET['action']) ? trim($_GET['action']) : "";
$id = isset($_GET['id']) ? intval($_GET['id']) : "";

$row_details = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT * from contact WHERE id = %d", $id
    ), ARRAY_A
);


if (isset($_POST['btnsubmit'])) {

    $action = isset($_GET['action']) ? trim($_GET['action']) : "";
    $id = isset($_GET['id']) ? intval($_GET['id']) : "";

    if (!empty($action)) {

        $wpdb->update("contact", array(
            "countrycode" => $_POST['txtname'],
            "number" => $_POST['txtnumber']
        ), array(
            "id" => $id
        ));

        $msg = "Form data updated successfully";
    } else {

        $wpdb->insert("contact", array(
            "countrycode" => $_POST['txtname'],
            "number" => $_POST['txtnumber']
        ));

        if ($wpdb->insert_id > 0) {
            $msg = "Form data saved successfully";
        } else {
            $msg = "Failed to save data";
        }
    }
}
?>

<p><?php echo $msg; ?></p>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>?page=ContactManagementPlugin-add<?php
if (!empty($action)) {
    echo '&action=edit&id=' . $id;
}
?>" method="post">
    <p>
        <label>
            CountryCode
        </label>
        <input type="text" name="txtname" value="<?php echo isset($row_details['countrycode']) ? $row_details['countrycode'] : ""; ?>" placeholder="Enter CountryCode"/>
    </p>
    <p>
        <label>
            Number
        </label>
        <input type="number" name="txtnumber" value="<?php echo isset($row_details['number']) ? $row_details['number'] : ""; ?>" placeholder="Enter Number"/>
    </p>
    <p>
        <button type="submit" name="btnsubmit">Submit</button>
    </p>
</form>