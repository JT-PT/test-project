<?php
global $wpdb;
$all_contacts = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT * from contact", ""
    ), ARRAY_A
);

$action = isset($_GET['action']) ? trim($_GET['action']) : "";
$id = isset($_GET['id']) ? intval($_GET['id']) : "";
if (!empty($action) && $action == "delete") {

    $row_exists = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * from contact WHERE id = %d", $id
        )
    );
    if (count($row_exists) > 0) {
        $wpdb->delete("contact", array(
            "id" => $id
        ));
    }
    ?>
    <script>
        location.href = "<?php echo site_url() ?>/wp-admin/admin.php?page=PersonManagementPlugin-plugin";
    </script>
    <?php
}

if (count($all_contacts) > 0) {
    ?>
    <table cellpadding="10" border="1" width="100px">
        <tr>
            <th>Id</th>
            <th>CountryCode</th>
            <th>Number</th>
        </tr>
        <?php
        $count = 1;
        foreach ($all_contacts as $index => $person) {
            ?>
            <tr>
                <td><?php echo $count++; ?></td>
                <td><?php echo $person['countrycode'] ?></td>
                <td><?php echo $person['number'] ?></td>
            </tr>
            <?php
        }
        ?>
    </table>

    <?php
}
?>
