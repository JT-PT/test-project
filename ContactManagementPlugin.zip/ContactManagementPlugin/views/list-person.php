<?php
global $wpdb;
$all_people = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT * from person", ""
    ), ARRAY_A
);

$action = isset($_GET['action']) ? trim($_GET['action']) : "";
$id = isset($_GET['id']) ? intval($_GET['id']) : "";
if (!empty($action) && $action == "delete") {

    $row_exists = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * from person WHERE id = %d", $id
        )
    );
    if (count($row_exists) > 0) {
        $wpdb->delete("person", array(
            "id" => $id
        ));
    }
    ?>
    <script>
        location.href = "<?php echo site_url() ?>/wp-admin/admin.php?page=PersonManagementPlugin-plugin";
    </script>
    <?php
}

if (count($all_people) > 0) {
    ?>
    <table cellpadding="10" border="1" width="100px">
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Email</th>
        </tr>
        <?php
        $count = 1;
        foreach ($all_people as $index => $person) {
            ?>
            <tr>
                <td><?php echo $count++; ?></td>
                <td><?php echo $person['name'] ?></td>
                <td><?php echo $person['email'] ?></td>
            </tr>
            <?php
        }
        ?>
    </table>

    <?php
}
?>
