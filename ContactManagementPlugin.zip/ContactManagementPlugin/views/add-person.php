<?php
global $wpdb;
$all_people = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT * from person", ""
    ), ARRAY_A
);

$action = isset($_GET['action']) ? trim($_GET['action']) : "";
$id = isset($_GET['id']) ? intval($_GET['id']) : "";
if (!empty($action) && $action == "delete") {

    $row_exists = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * from person WHERE id = %d", $id
        )
    );
    if (count($row_exists) > 0) {
        $wpdb->delete("person", array(
            "id" => $id
        ));
    }
    ?>
    <script>
        location.href = "<?php echo site_url() ?>/wp-admin/admin.php?page=PersonManagementPlugin-plugin";
    </script>
    <?php
}

if (count($all_people) > 0) {
    ?>
    <table cellpadding="10" border="1" width="100px">
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Action</th>
        </tr>
        <?php
        $count = 1;
        foreach ($all_people as $index => $person) {
            ?>
            <tr>
                <td><?php echo $count++; ?></td>
                <td><?php echo $person['name'] ?></td>
                <td><?php echo $person['email'] ?></td>
                <td>
                    <a href="admin.php?page=PersonManagementPlugin-add&action=edit&id=<?php echo $person['id']; ?>">Edit</a>
                    <a href="admin.php?page=PersonManagementPlugin-plugin&id=<?php echo $person['id']; ?>&action=delete" onclick="return confirm('Are you sure you want to delete this person?')">Delete</a>
                </td>
            </tr>
            <?php
        }
        ?>
    </table>

    <?php
}
?>

<?php
global $wpdb;
$msg = '';

$action = isset($_GET['action']) ? trim($_GET['action']) : "";
$id = isset($_GET['id']) ? intval($_GET['id']) : "";

$row_details = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT * from person WHERE id = %d", $id
    ), ARRAY_A
);


if (isset($_POST['btnsubmit'])) {

    $action = isset($_GET['action']) ? trim($_GET['action']) : "";
    $id = isset($_GET['id']) ? intval($_GET['id']) : "";

    if (!empty($action)) {

        $wpdb->update("person", array(
            "name" => $_POST['txtname'],
            "email" => $_POST['txtemail']
        ), array(
            "id" => $id
        ));

        $msg = "Form data updated successfully";
    } else {

        $wpdb->insert("person", array(
            "name" => $_POST['txtname'],
            "email" => $_POST['txtemail']
        ));

        if ($wpdb->insert_id > 0) {
            $msg = "Form data saved successfully";
        } else {
            $msg = "Failed to save data";
        }
    }
}
?>

<p><?php echo $msg; ?></p>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>?page=PersonManagementPlugin-add<?php
if (!empty($action)) {
    echo '&action=edit&id=' . $id;
}
?>" method="post">
    <p>
        <label>
            Name
        </label>
        <input type="text" name="txtname" value="<?php echo isset($row_details['name']) ? $row_details['name'] : ""; ?>" placeholder="Enter name"/>
    </p>
    <p>
        <label>
            Email
        </label>
        <input type="email" name="txtemail" value="<?php echo isset($row_details['email']) ? $row_details['email'] : ""; ?>" placeholder="Enter email"/>
    </p>
    <p>
        <button type="submit" name="btnsubmit">Submit</button>
    </p>
</form>