<?php
/*
  Plugin Name: Contact Management Plugin
  Description: A test plugin for alfasoft
  Version: 1.0.0
  Author: João Teixeira
 */

define("NEXT_PLUGIN_DIR_PATH", plugin_dir_path(__FILE__));

function next_menus_development() {
    add_menu_page("Contact Management Plugin", "Contact Management Plugin", "manage_options","PersonManagementPlugin-plugin", "PersonManagementPlugin_list_call");
    add_submenu_page("PersonManagementPlugin-plugin", "Add person", "Add person", "manage_options", "PersonManagementPlugin-add", "PersonManagementPlugin_add_call");
    add_submenu_page("PersonManagementPlugin-plugin", "Add contacts", "Add contacts", "manage_options", "ContactManagementPlugin-add", "ContactManagementPlugin_add_call");

}

add_action("admin_menu", "next_menus_development");

function PersonManagementPlugin_list_call() {
    include_once NEXT_PLUGIN_DIR_PATH . '/views/list-person.php';
}

function PersonManagementPlugin_add_call() {
    include_once NEXT_PLUGIN_DIR_PATH . '/views/add-person.php';
}

function ContactManagementPlugin_list_call() {
    include_once NEXT_PLUGIN_DIR_PATH . '/views/list-contacts.php';
}

function ContactManagementPlugin_add_call() {
    include_once NEXT_PLUGIN_DIR_PATH . '/views/add-contacts.php';
}

?>
